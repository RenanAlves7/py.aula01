print (2+3)

print ("2" + "3")

print ("Olá," + "mundo!")

print ("O resultado da soma de 2 + 3 e:", 2 + 3)

print (10*(5+7)/4)

print (10*(5+7/4))
